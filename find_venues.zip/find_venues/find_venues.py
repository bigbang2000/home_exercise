import json, sys

# parse args and get the persons list that will attend, quit if no names are provided.
if len(sys.argv) < 2:
    print("please input valid names list.")
    exit()
else:
    persons_attending = sys.argv[1].split(",")
    

# load users.json file
with open('users.json') as users_file:
    persons = json.load(users_file)

# load venues.json file
with open('venues.json') as venues_file:
    venues = json.load(venues_file)



places_to_avoid = {}

"""
The following is the main logic to calculate the places_to_avoid list.
The basic idea is, for each attending person:
1, calculate set difference, venue's food list - wont_eat list, if result list is empty, append it to places_to_avoid list
2, calculate set intersection, venue's drink list & wont_eat list, if result list is empty, append it to places_to_avoid list
"""

for pa in persons_attending:
    for person in persons:
        if person["name"] == pa.strip():

            for venue in venues:

                # standardise food name by converting each item in wont_eat and venue's food list into lowercase
                lowercase_venue_food = map(lambda x: x.lower(), venue["food"])
                lowercase_person_wont_eat = map(lambda x: x.lower(), person['wont_eat'])

                if len(set(lowercase_venue_food).difference(set(lowercase_person_wont_eat))) == 0:
                    if venue["name"] in places_to_avoid:
                        places_to_avoid.get(venue["name"]).append("There is nothing for "+ person["name"] +" to eat.")
                    else:
                        places_to_avoid[venue["name"]] = ["There is nothing for "+ person["name"] +" to eat."]

                # standardise drinks name by converting each item in person' and venue's drink list into lowercase
                lowercase_venue_drinks = map(lambda x: x.lower(), venue["drinks"])
                lowercase_person_drinks = map(lambda x: x.lower(), person['drinks'])

                if len((set(lowercase_venue_drinks).intersection(set(lowercase_person_drinks)))) == 0:
                    if venue["name"] in places_to_avoid:
                        places_to_avoid.get(venue["name"]).append("There is nothing for "+ person["name"] +" to drink.")
                    else:
                        places_to_avoid[venue["name"]] = ["There is nothing for "+ person["name"] +" to drink."]


# compile the total venues' name list
venue_names = []
for venue in venues:
    venue_names.append(venue["name"])

# calculate places_to_visit list by venue_names - places_to_avoid.keys()
places_to_visit = venue_names - places_to_avoid.keys()

# the following is to compile final json output
places_to_avoid_list = []
for name, reason in places_to_avoid.items():
    place_dict = {}
    place_dict["name"] = name
    place_dict["reason"] = reason
    places_to_avoid_list.append(place_dict)

json_output = {}
json_output["places_to_visit"] = list(places_to_visit)
json_output["places_to_avoid"] = places_to_avoid_list
print(json.dumps(json_output, indent=4))